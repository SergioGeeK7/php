<?php 


class saluda {
	

function saludo (){
	

echo "yo te saludo";

}


function adios (){
	

echo "yo te digo adios";

}

}



$instancia = new saluda();


$instancia->saludo();


?>