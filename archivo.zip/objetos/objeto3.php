<?php 


class dinosalgo {


var $atributo;

function dinosalgo ($algo){

	$this->atributo=$algo;
	echo($this->atributo);

}

}
include 

$decir = new dinosalgo("Oola");



?>