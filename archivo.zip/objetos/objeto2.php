<?php


class dimealgo {


// constructor
function dimealgo ($algo){

echo("lo que te voy a desie es esto ").$algo;


}


}



$desir= new dimealgo("Wenas !!!");



?>