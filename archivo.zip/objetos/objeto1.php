<?php 

// para un objeto necesitamos minumo una estructura class

/**
* 
*/
class objeto {

// atributos == variables

var variable1;
var variable2;


// metodos son funciones	

function metodo1 (){


}


function metodo2 ($parametro1,$parametro2){



}


}





?>