<?php


echo("yo soy el contenido original");
require "include.php"; // incluira y ejecutara el contenido de include .php si no esta lanzara un fatal error.





?>