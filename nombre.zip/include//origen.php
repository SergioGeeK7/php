
<?php


echo("yo soy el contenido original");
include "include.php"; // incluira y ejecutara el contenido de include .php


?>