<?php


$fruta="pera";


?>